<?php
session_start();

if (!isset($_SESSION['guest_id'])) {
    header("Location: guest_login.php");
    exit();
}

include 'db_connect.php';
$guest_name = $_SESSION['guest_name'];
?>

<!DOCTYPE html>
<html>
<head>
    <title>Apply for Job</title>
    <link rel="stylesheet" href="apply_employee_vacancies.css">
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;500;700&display=swap" rel="stylesheet">
</head>
<body>

<div class="dashboard-container">
        <!-- Sidebar Navigation -->
        <aside class="sidebar">
            <div class="logo-container">
                <img src="The_Salvation_Army.png" alt="Salvation Army Logo" class="logo">
                <div><h2>Salvation Army Girl's Hostel</h2>
            </div></div>
            
            
            <nav class="sidebar-menu">
                <ul>
                    <li class="active">
                        <a href="guest_dashboard.php">
                            <i class="fas fa-home"></i>
                            <span>Dashboard</span>
                        </a>
                    </li>
                    <li>
                        <a href="social_services.php">
                            <i class="fas fa-gopuram"></i>
                            <span>Social Services</span>
                        </a>
                    </li>
                    <li>
                        <a href="#jobs">
                            <i class="fas fa-briefcase"></i>
                            <span>Job Opportunities</span>
                        </a>
                    </li>
                    <li>
                        <a href="#profile">
                            <i class="fas fa-user"></i>
                            <span>Profile</span>
                        </a>
                    </li>
                </ul>
            </nav>
            
            <div class="sidebar-footer">
                <a href="guest_logout.php" class="logout-btn">
                    <i class="fas fa-sign-out-alt"></i>
                    <span>Logout</span>
                </a>
            </div>
        </aside>

        <!-- Main Content Area -->
        <main class="main-content">
            <header class="dashboard-header">
                <div class="header-left">
                    <h1>Welcome, <?php echo htmlspecialchars($guest_name); ?>!</h1>
                </div>
                <div class="header-right">
                    <div class="notification-icon">
                        <i class="fas fa-bell"></i>
                        <span class="notification-badge">3</span>
                    </div>
                    <div class="user-profile">
                        <img src="guest.jpg" alt="Profile Picture">
                    </div>
                </div>
                
            </header>

    <h2>Apply for Job</h2>

    <?php
    // Fetch open job vacancies for dropdown
    $query = "SELECT vacancy_id, job_title FROM employee_vacancies WHERE status = 'Open'";
    $result = mysqli_query($conn, $query);
    ?>

    <form action="submit_application.php" method="POST">
        <label for="vacancy">Select Job Vacancy:</label>
        <select name="vacancy_id" required>
            <?php
            // Populate dropdown with job vacancies
            while ($row = mysqli_fetch_assoc($result)) {
                echo "<option value='" . $row['vacancy_id'] . "'>" . $row['job_title'] . "</option>";
            }
            ?>
        </select>
        <br><br>

        <label for="name">Name:</label>
        <input type="text" name="applicant_name" required>
        <br><br>

        <label for="email">Email:</label>
        <input type="email" name="contact_email" required>
        <br><br>

        <label for="phone">Phone:</label>
        <input type="tel" name="contact_phone" required>
        <br><br>

        <label for="cover_letter">Qualifications:</label><br>
        <textarea name="cover_letter" rows="5" cols="40" required></textarea>
        <br><br>

        <button type="submit">Submit Application</button>
    </form>
</body>
</html>
